Author: Ifinder (me)

Argos 2.0 was a joke and it somehow got redistributed by people with malicious intentions and it is on google if you type "ArgosCrypt"
you will see that theres fake how to fix guides and some details and stuff so ye.